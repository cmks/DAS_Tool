#
# DAS Tool for genome-resolved metagenomics
# by Christian MK Sieber (csieber@lbl.gov)
#

#' DAS Tool
#'
#' This is the main function of DAS Tool.
#' Please use DAS_Tool.sh in your installation folder to run DAS Tool.
#' DAS Tool is available at https://github.com/cmks/DAS_Tool
#' Please cite https://doi.org/10.1101/107789
#'
#' @param scaffolds_to_bins Comma separated string of tab separated scaffolds to bin files.
#' @param bin_set_labels Comma separated string of binning prediction names.
#' @param length_table Tab separated file of scaffold names and scaffold lengths.
#' @param bac_scg_matrix Tab separated file of scaffold names and predicted bacterial single copy genes.
#' @param arc_scg_matrix Tab separated file of scaffold names and predicted archaeal single copy genes.
#' @param score_threshold Score threshold until selection algorithm will keep selecting bins [0..1].
#' @param output_basename Basename of output files.
#' @param trim_headers Logical value indicating whether scaffold headers should be trimmed after the first whitespace.
#' @param write_bin_evals  Logical value indicating whether evaluations for each input bin set should be written.
#' @return List of binning evaluations.
cherry_pick <- function(scaffolds_to_bins,bin_set_labels='NULL',length_table,bac_scg_matrix,arc_scg_matrix,score_threshold=0.1,a=1,b=0.6,c=0.5,output_basename='DASTool',trim_headers=T,use_N50=T,write_bin_evals=T,write_unbinned=F,debug=F){

  logfile <- paste(output_basename,'_DASTool.log',sep='')
  if(debug){
    write.log(message = paste0('scaffolds_to_bins ',scaffolds_to_bins),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('bin_set_labels ',bin_set_labels),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('assembly ',assembly),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('bac_scg_matrix ',bac_scg_matrix),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('arc_scg_matrix ',arc_scg_matrix),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('output_basename ',output_basename),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('score_threshold ',score_threshold),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('threads ',threads),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('workingdir ',getwd()),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('length_table ',length_table),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('write_bin_evals ',write_bin_evals),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('create_plots ',create_plots),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('debug ',debug),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('b ',b),filename = logfile,write_to_stdout = F)
    write.log(message = paste0('c ',c),filename = logfile,write_to_stdout = F)
  }

  rank_bins=F
  score_threshold <- max(score_threshold,-41)
  internal_ratio_threshold <- 0.0
  internal_score_threshold <- min(0.0,score_threshold)
  logfile <- paste(output_basename,'_DASTool.log',sep='')

  if(bin_set_labels=="NULL"){
    bin_set_labels <- NULL
  }

  #
  # get assembly information
  # assembly_info <- data.table(scaffold_name=names(scaffolds),length=width(scaffolds))
  assembly_info <- fread(length_table,sep='\t',header=F,col.names=c('scaffold_name','length'))


  if(trim_headers){
    assembly_info$scaffold_name <- gsub(' .*','',assembly_info$scaffold_name)
  }


  setkey(assembly_info,scaffold_name)


  #Read bin-set bin2scaffold-files:
  bin_sets <- unlist(strsplit(scaffolds_to_bins,','))
  bin_set_list <- list()
  uqbins <- data.frame()
  for(i in 1:length(bin_sets)){

    result = tryCatch({
      bin_set_list[[i]] <- read.table(bin_sets[i],header = F,sep = '\t',stringsAsFactors = F)
      colnames(bin_set_list[[i]]) <- c('scaffold_name','bin')

      if(max(table(bin_set_list[[i]]$scaffold_name)) > 1){
        write.log(message = paste0('WARNING: Duplicated scaffolds in: ', bin_sets[i]),filename = logfile)
        if(length(unique(bin_set_list[[i]]$scaffold_name)) < length(unique(bin_set_list[[i]]$bin))){
          write.log(message = paste0('\tscaffold_name and bin_id columns flipped? Should be: scaffold_name \\t bin_id'),filename = logfile)
        }
      }
    }, error = function(e) {
      write.log(message = paste0('ERROR: Cannot read scaffold2bin file: ',bin_sets[i],'.\n\tPlease check file/format. Should be: scaffold_name \\t bin_id'),filename = logfile)
    })

    uqbins <- rbind(uqbins,data.frame(bin=unique(bin_set_list[[i]]$bin),binset=basename(bin_sets[i])))

    if(trim_headers){
      bin_set_list[[i]]$scaffold_name <- gsub(' .*','',bin_set_list[[i]]$scaffold_name)
    }

    #check if scaffolds of scaffolds2bin match names in assembly_info:
    if(!any( bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name )){
      write.log(message = paste0('ERROR: Scaffold names of',bin_sets[i],'do not match assembly headers:'),filename = logfile)
      write.log(message = paste0('\tFormat of ',basename(assembly),': ', paste(head(assembly_info$scaffold_name),collapse=' ')),filename = logfile)
      write.log(message = paste0('\tFormat of ',basename(bin_sets[i]),': ', paste(head(bin_set_list[[i]]$scaffold_name),collapse=' ')),filename = logfile)
      return(F) #Exit here
    }else if(!all( bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name )){
      write.log(message = paste0('WARNING: Some scaffold names of',bin_sets[i],'do not match assembly headers:'),filename = logfile)
      write.log(message = paste0('\t', paste(head(bin_set_list[[i]]$scaffold_name[ ! bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name]),collapse=' ')),filename = logfile)
    }

  }

  #Any scaffold2bin file names duplicated?
  this_labels <- paste0('Binner',sprintf("%02d",c(1:length(bin_sets))))
  if(!any(duplicated(basename(bin_sets)))){
    this_labels <- basename(bin_sets)
  }
  
  #Are bin set labels given?
  if(!is.null(bin_set_labels)){
    #Number of bin-sets and labels are the same?
    if( length(basename(bin_sets)) == length(unlist(strsplit(bin_set_labels,',')))){
      #Are bin set labels unique?
      if(! any( duplicated(unlist(strsplit(bin_set_labels,','))) )){
        this_labels <- unlist(strsplit(bin_set_labels,','))
      }else{
        write.log(message = paste0('WARNING: bin set labels are not unique.\n \tPlease provide unique labels for each bin set (--labels).\n \tCreating generic labels for now.\n'),filename = logfile)
      }
    }else if(any(duplicated(basename(bin_sets)))){
      write.log(message = paste0('WARNING: Number of bin-sets does not match number of labels AND scaffold2bin file names are not unique.\n \tPlease provide labels for each bin set (--labels).\n \tCreating generic labels for now.\n'),filename = logfile)
    }
  }else if(any(duplicated(basename(bin_sets)))){
    write.log(message = paste0('WARNING: No bin set labels given AND scaffold2bin file names are not unique.\n Please provide unique labels (--labels).\n Creating generic labels for now.\n'),filename = logfile)
  }

  #Rename bin-IDs if not unique:
  uqtest <- table(uqbins$bin)
  if(max(uqtest) > 1){
    write.log(message = paste0('WARNING: non-unique bin-IDs found\n\tcreating unique bin-IDs\n'),filename = logfile)
    for(i in 1:length(bin_sets)){
      bins_uq <- unique(bin_set_list[[i]]$bin)
      map <- data.frame(new=gsub('_scaffolds2bin','',paste(this_labels[i],'.',sprintf('%03d',c(1:length(bins_uq))),sep='')),old=bins_uq)
      bin_set_list[[i]]$bin <- map$new[ match(bin_set_list[[i]]$bin,map$old) ]
    }
  }  
  
  #Name bin sets:
  names(bin_set_list) <- this_labels
  
  #
  # Build scg_matrix
  # cat('assembling SCG matrix\n')
  if(file.exists(bac_scg_matrix)){
    bac_scg <- read.table(bac_scg_matrix, header = F,sep = '\t',stringsAsFactors = F,quote = '',col.names=c('contig','Bacterial.SCG'))
    bac_scg$contig <- gsub('\\_[0-9]+$','',bac_scg$contig)
    
    if(! any(bac_scg$contig %in% assembly_info$scaffold_name)){
      bac_scg$contig <- gsub('\\_[0-9]+$','',bac_scg$contig)
    }
    
    bac_scg$tmp  <- paste(bac_scg$contig,bac_scg$Bacterial.SCG,sep = '_')
    bac_scg <- bac_scg[!duplicated(bac_scg$tmp),]
    tmp  <- table(bac_scg$tmp)
    bac_scg$count <- tmp[bac_scg$tmp]
    tmp2 <- aggregate(bac_scg["count"], by=bac_scg[c("Bacterial.SCG","contig")], FUN=sum)
    bacSCGMat <- reshape(tmp2,timevar = 'Bacterial.SCG',idvar = 'contig',direction = "wide")
    colnames(bacSCGMat) <- gsub('^count\\.','Bac_',colnames(bacSCGMat))
    
    SCGMat <- bacSCGMat #in case arc_scg_matrix is 0, otherwise overwrite later
  }

  if(file.exists(arc_scg_matrix)){
    arc_scg <- read.table(arc_scg_matrix, header = F,sep = '\t',stringsAsFactors = F,quote = '',col.names=c('contig','Archaeal.SCG'))
    arc_scg$contig <- gsub('\\_[0-9]+$','',arc_scg$contig)
    
    if(! any(arc_scg$contig %in% assembly_info$scaffold_name)){
      arc_scg$contig <- gsub('\\_[0-9]+$','',arc_scg$contig)
    }
    
    arc_scg$tmp  <- paste(arc_scg$contig,arc_scg$Archaeal.SCG,sep = '_')
    arc_scg <- arc_scg[!duplicated(arc_scg$tmp),]
    tmp  <- table(arc_scg$tmp)
    arc_scg$count <- tmp[arc_scg$tmp]
    tmp2 <- aggregate(arc_scg["count"], by=arc_scg[c("Archaeal.SCG","contig")], FUN=sum)
    arcSCGMat <- reshape(tmp2,timevar = 'Archaeal.SCG',idvar = 'contig',direction = "wide")
    colnames(arcSCGMat) <- gsub('^count\\.','Arc_',colnames(arcSCGMat))
    
    SCGMat <- arcSCGMat #in case bac_scg_matrix is 0, otherwise overwrite later
  }
  
  if(file.exists(bac_scg_matrix) && file.exists(arc_scg_matrix)){
    SCGMat <- merge(x = bacSCGMat, y = arcSCGMat, by = "contig", all = TRUE)
    SCGMat[is.na(SCGMat)] <- 0
    rownames(SCGMat) <- SCGMat$contig
  # }else if( file.size(bac_scg_matrix) > 0 && file.size(arc_scg_matrix) == 0 ){
  #   SCGMat <- bacSCGMat
  # }else if(file.size(bac_scg_matrix) > 0 && file.size(arc_scg_matrix) == 0 ){
  #   SCGMat <- arcSCGMat
  # }else{
  #   # STOP
  }

  if(trim_headers){
    SCGMat$contig <- gsub(' .*','',SCGMat$contig)
  }
  SCGMat <- as.data.table(SCGMat)
  setkey(SCGMat,contig)


  #
  # evaluate bin-sets
  cat('evaluating bin-sets\n')
  eval_bin_set_list <- list()
  pretty_tables <- list()
  pretty_tables[names(bin_set_list)] <- list(NULL)
  eval_bin_set_list[names(bin_set_list)] <- list(NULL)
  for(i in 1:length(bin_set_list)){

    eval_bin_set_list[[i]] <- evaluateBinsDTParallel_2(bin_table = bin_set_list[[i]],SCGMat,assembly_info,a=a,b=b,c=c,method=rank_bins)

    pretty_tables[[i]] <- data.table(bin=eval_bin_set_list[[i]]$bin,
                                     uniqueBacSCGs=eval_bin_set_list[[i]]$uniqueBacSCGs,
                                     redundantBacSCGs=eval_bin_set_list[[i]]$multipleBacSCGs,
                                     uniqueArcSCGs=eval_bin_set_list[[i]]$uniqueArcSCGs,
                                     redundantArcSCGs=eval_bin_set_list[[i]]$multipleArcSCGs,
                                     bacRatio=eval_bin_set_list[[i]]$bacRatio,
                                     arcRatio=eval_bin_set_list[[i]]$arcRatio,
                                     size=eval_bin_set_list[[i]]$size,
                                     contigs=eval_bin_set_list[[i]]$nContigs,
                                     N50=eval_bin_set_list[[i]]$N50,
                                     binScore=round(eval_bin_set_list[[i]]$score,4),
                                     SCG_completeness=round(apply(data.frame(b=eval_bin_set_list[[i]]$bacRatio,a=eval_bin_set_list[[i]]$arcRatio),1,max)*100,2),
                                     SCG_redundancy=round(apply(data.frame(b=eval_bin_set_list[[i]]$multipleBacSCGs/51,a=eval_bin_set_list[[i]]$multipleArcSCGs/38),1,max)*100,2))


    if(write_bin_evals){
      write.table(pretty_tables[[i]],paste(output_basename,'_',names(bin_set_list)[i],'.eval',sep=''),sep='\t',col.names=T,row.names=F,quote=F)
    }
    eval_bin_set_list[[i]] <- eval_bin_set_list[[i]][eval_bin_set_list[[i]]$score> min(score_threshold,-10),]
    bin_set_list[[i]] <- as.data.table(bin_set_list[[i]])
    setkey(bin_set_list[[i]],bin)
    bin_set_list[[i]] <- bin_set_list[[i]][.(eval_bin_set_list[[i]]$bin)]
  }


  bin_list <- list()
  for(i in 1:length(bin_set_list)){
    binS1 <- bin_set_list[[i]]
    if(debug){
      cat('binS1 #',i,' dimensions: ',dim(binS1)[1],' x ',dim(binS1)[2],'\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
      write.log(message = head(binS1),filename = logfile,write_to_stdout = F)
    }
    bin_list[[(length(bin_list)+1)]] <- data.table(bin=binS1$bin,scaffold_name=binS1$scaffold_name)
  }

  bin_table <- rbindlist(bin_list,fill = T)
  if(debug){
    cat('bin_table dimensions: ',dim(bin_table)[1],' x ',dim(bin_table)[2],'\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
    write.log(message = head(bin_table),filename = logfile,write_to_stdout = F)
  }
  bin_summary <- evaluateBinsDTParallel_2(bin_table,SCGMat,assembly_info = assembly_info,a=a,b=b,c=c,method=rank_bins)
  bin_summary$maxRatio  <- apply(data.frame(bin_summary$bacRatio, bin_summary$arcRatio),1,max)

  optibin_table <- list()
  optibin_summary <- list()
  optimization_trace <- list()

  bin_table  <- bin_table[ bin_table$bin %in% bin_summary$bin[ bin_summary$maxRatio > internal_ratio_threshold ],]
  bin_table <- bin_table[,.(scaffold_name,bin)]
  setkey(bin_table,bin)
  bin_summary <- bin_summary[ bin_summary$maxRatio > internal_ratio_threshold, ]

  if(use_N50){
    bin_summary <- bin_summary[order(bin_summary$score,bin_summary$N50,bin_summary$size,decreasing = T),]
    bin_summary <- bin_summary[,maxRatio:=NULL]
  }else{
    bin_summary <- bin_summary[order(bin_summary$score,bin_summary$size,decreasing = T),]
    bin_summary <- bin_summary[,maxRatio:=NULL]
  }

  # Compute Score-Matrix and Rank-Scores
  max_score <- max(bin_summary$score)

  if(max_score < score_threshold){
    write.log(message = paste0('No bins with bin-score >', score_threshold, ' found. Adjust score_threshold to report bins with lower quality.\n Aborting.\n'),filename = logfile)
    return(-1)
  }

  first=T
  sub_bins <- c()
  write.log(message = paste0('starting bin selection from ', dim(bin_summary)[1],' bins'),filename = logfile,write_to_stdout = T)
  step <- 1
  while(max_score > internal_score_threshold){


    if(max_score >= score_threshold && max(bin_summary$bacRatio[1],bin_summary$arcRatio[1]) > internal_ratio_threshold){
      cat('|')
        write.table(bin_table[ .(bin_summary$bin[1]) ],file=paste(output_basename,'_DASTool_scaffolds2bin.txt',sep=''),append = !first,quote=F,row.names = F,col.names=F,sep='\t')
        l <- bin_summary$bin ==  bin_summary$bin[1]
        write.table(data.table(bin=bin_summary$bin[l],
                               uniqueBacSCGs=bin_summary$uniqueBacSCGs[l],
                               redundantBacSCGs=bin_summary$multipleBacSCGs[l],
                                 uniqueArcSCGs=bin_summary$uniqueArcSCGs[l],
                                 redundantArcSCGs=bin_summary$multipleArcSCGs[l],
                                 bacRatio=bin_summary$bacRatio[l],
                                 arcRatio=bin_summary$arcRatio[l],
                                 size=bin_summary$size[l],
                                 contigs=bin_summary$nContigs[l],
                                 N50=bin_summary$N50[l],
                                 binScore=round(bin_summary$score[l],4),
                                 SCG_completeness=round(max(bin_summary$bacRatio[l],bin_summary$arcRatio[l])*100,2),
                                 SCG_redundancy=round(max(bin_summary$multipleBacSCGs[l]/51,bin_summary$multipleArcSCGs[l]/38)*100,2)),file=paste(output_basename,'_DASTool_summary.txt',sep=''),append = !first,quote=F,row.names = F,col.names=first,sep='\t')
        first=F
     }

    affected_scaffolds <- bin_table[ .(bin_summary$bin[1]), scaffold_name ]
    affected_bins <- unique(bin_table[ bin_table$scaffold_name %in% affected_scaffolds , bin])

    if(debug){
      write.log(message = paste0('================== Iteration No ',step,': =================='),filename = logfile,write_to_stdout = F)
      write.log(message = paste0('Selected bin:'),filename = logfile,write_to_stdout = F)
      write.log(message = bin_summary[ bin_summary$bin ==  bin_summary$bin[1], ],filename = logfile,write_to_stdout = F)
      write.log(message = paste0('-------------------'),filename = logfile,write_to_stdout = F)
      write.log(message = paste0('Affected bins:'),filename = logfile,write_to_stdout = F)
      write.log(message = bin_summary[ bin_summary$bin %in% affected_bins, ],filename = logfile,write_to_stdout = F)
    }

    bin_table <- bin_table[ !bin_table$scaffold_name %in% affected_scaffolds ,]
    bin_summary <- bin_summary[ !bin_summary$bin %in% affected_bins, ]

    affected_bin_table <- bin_table[ .(affected_bins), ]
    affected_bin_table <- affected_bin_table[!is.na(affected_bin_table$scaffold_name),]

    if(dim(affected_bin_table)[1] > 0){

      new_bin_summary <- evaluateBinsDTParallel_2(bin_table = affected_bin_table, SCGMat,assembly_info = assembly_info,a=a,b=b,c=c,method=rank_bins)
      sub_bins <- unique(c(sub_bins,new_bin_summary$bin))
      if(rank_bins){
        new_bin_summary$r <- bin_rank$rank[match(new_bin_summary$method,bin_rank$method)]
      }
      new_bin_summary <- new_bin_summary[ new_bin_summary$sumBacSCGs>0 | new_bin_summary$sumArcSCGs>0, ]
      bin_summary <- rbind(bin_summary,new_bin_summary)

      if(debug){
        write.log(message = '-------------------',filename = logfile,write_to_stdout = F)
        write.log(message = 'Updated bins:',filename = logfile,write_to_stdout = F)
        write.log(message = new_bin_summary,filename = logfile,write_to_stdout = F)
      }
    }

    if(dim(bin_summary)[1] != 0){
      if(use_N50){
        bin_summary <- bin_summary[order(bin_summary$score,bin_summary$N50,bin_summary$size,decreasing = T),]
        max_score <- max(bin_summary$score)
      }else{
        bin_summary <- bin_summary[order(bin_summary$score,bin_summary$size,decreasing = T),]
        max_score <- max(bin_summary$score)
      }

    }else{
      max_score <- -42
    }
    step <- step + 1
  }
  cat('\n')

  dastool_bineval <- read.table(paste0(output_basename,'_DASTool_summary.txt',sep=''),header=T,stringsAsFactors = F)
  if(any(dastool_bineval$bin %in% sub_bins)){
    dastool_bineval$bin[ dastool_bineval$bin %in% sub_bins ] <- paste0(dastool_bineval$bin[ dastool_bineval$bin %in% sub_bins ],'_sub')
    write.table(dastool_bineval,paste0(output_basename,'_DASTool_summary.txt'),sep='\t',col.names = T,row.names = F,quote=F)
    dastool_bintable <- read.table(paste0(output_basename,'_DASTool_scaffolds2bin.txt'),sep='\t',header=F,stringsAsFactors = F)
    dastool_bintable$V2[dastool_bintable$V2 %in% sub_bins] <-  paste0(dastool_bintable$V2[dastool_bintable$V2 %in% sub_bins],'_sub')
    write.table(dastool_bintable,paste0(output_basename,'_DASTool_scaffolds2bin.txt'),sep='\t',col.names = F,row.names = F,quote=F)
  }
  
  reported_bins <- nrow(dastool_bineval)
  
  #Write unbinned:
  if(write_unbinned){
    write.log(message = 'writing unbinned contigs',filename = logfile,write_to_stdout = T)
    if(nrow(bin_table)>0){
      dastool_bintable <- fread(paste0(output_basename,'_DASTool_scaffolds2bin.txt'),sep='\t',header=F,stringsAsFactors = F)
      
      unbinned_contigs <- assembly_info[ ! assembly_info$scaffold_name %in% dastool_bintable[,V1] , scaffold_name]
      
      dastool_bintable <- rbind(dastool_bintable,data.table(V1=unbinned_contigs,V2='unbinned'))
      write.table(dastool_bintable,paste0(output_basename,'_DASTool_scaffolds2bin.txt'),sep='\t',col.names = F,row.names = F,quote=F)
      
      unbinned_summary <- evaluateBinsDTParallel_2(bin_table = data.table(scaffold_name=unbinned_contigs,bin='unbinned'), SCGMat,assembly_info = assembly_info,a=a,b=b,c=c,method=rank_bins)
      dastool_bineval <- rbind(dastool_bineval,data.table(bin=unbinned_summary$bin,
                                                          uniqueBacSCGs=unbinned_summary$uniqueBacSCGs,
                                                          redundantBacSCGs=unbinned_summary$multipleBacSCGs,
                                                          uniqueArcSCGs=unbinned_summary$uniqueArcSCGs,
                                                          redundantArcSCGs=unbinned_summary$multipleArcSCGs,
                                                          bacRatio=unbinned_summary$bacRatio,
                                                          arcRatio=unbinned_summary$arcRatio,
                                                          size=unbinned_summary$size,
                                                          contigs=unbinned_summary$nContigs,
                                                          N50=unbinned_summary$N50,
                                                          binScore=round(unbinned_summary$score,4),
                                                          SCG_completeness=round(apply(data.frame(b=unbinned_summary$bacRatio,a=unbinned_summary$arcRatio),1,max)*100,2),
                                                          SCG_redundancy=round(apply(data.frame(b=unbinned_summary$multipleBacSCGs/51,a=unbinned_summary$multipleArcSCGs/38),1,max)*100,2)))
      
      write.table(dastool_bineval,paste0(output_basename,'_DASTool_summary.txt'),sep='\t',col.names = T,row.names = F,quote=F)
    }else{
      write.log(message = 'no unbinned contigs found',filename = logfile,write_to_stdout = T)
    }
  }
  
  pretty_tables <- c(pretty_tables,list(DAS_Tool=dastool_bineval))

  write.log(message = paste0('bin selection complete: ',reported_bins,' bins above score threshold selected.'),filename = logfile,write_to_stdout = T)
  
  return(pretty_tables)
}


#
# scores a scaffold2bins table using a single copy gene matrix
evaluateBinsDTParallel_2 <- function(bin_table, SCGMat, assembly_info=NULL, a=1, b=1.5, c=1,hmm=F,method=F){

  bin_table <- as.data.table(bin_table)
  setkey(bin_table,bin)
  # if(!is.null(assembly_info)){
  #   scaffold_table <- data.table(scaffold_names=names(assembly_info),length=assembly_info)
  #   setkey(scaffold_table,scaffold_names)
  # }
  bins_uq <- unique(bin_table$bin)

  bin_stats_list <- foreach(i=1:length(bins_uq)) %dopar% {
    scaffold_ids <- unique(bin_table[.(bins_uq[i]), scaffold_name])
    if(!hmm){
      # cat(bins_uq[i],scaffold_ids[1],a,b,c)
      data.table(bin=bins_uq[i],scoreBinDT(scaffold_ids, SCG_mat=SCGMat, a=a, b=b, c=c, detailed_output=T))
    }else{
      data.table(bin=bins_uq[i],scoreBinDT_HMM(scaffold_ids, SCG_mat=SCGMat, a=a, b=b, c=c, detailed_output=T))
    }
  }
  bin_stats <- rbindlist(bin_stats_list,fill = T)

  # cat('assembly info:', is.null(assembly_info))
  if(!is.null(assembly_info)){
    bin_stats$size <- 0
    bin_stats$nContigs <- 0
    bin_stats$N50 <- 0
    for(i in 1:length(bin_stats$bin)){
      dt1 <- bin_table[.(bin_stats$bin[i]),  ]
      setkey(dt1,scaffold_name)
      bin_stats$size[i] <- assembly_info[ .(dt1[,scaffold_name]), sum(length,na.rm = T)]
      bin_stats$nContigs[i] <- dim(dt1)[1]
      bin_stats$N50[i] <- calc.N50(assembly_info[ .(dt1[,scaffold_name]), length])
    }
  }
  if(method){
    bin_stats$method <- unlist(lapply(bin_stats$bin,function(x){strsplit(x,'\\.')[[1]][1]}))
  }

  return(bin_stats)
}


#
# scores a single bin using a single copy gene matrix
scoreBinDT <- function(scaffold_ids, SCG_mat, a=1, b=1.5, c=1, detailed_output=F){

  if(! any(SCG_mat$contig %in% scaffold_ids)){

    return(data.frame(uniqueBacSCGs=0,multipleBacSCGs=0,additionalBacSCGs=0,sumBacSCGs=0,bacRatio=0,uniqueArcSCGs=0,multipleArcSCGs=0,additionalArcSCGs=0,sumArcSCGs=0,arcRatio=0,score=0))
  }

  tmp <- SCG_mat[ .(scaffold_ids) , ]
  tmp <- tmp[,contig :=NULL ]
  bin_stats <- tmp[, lapply(.SD, sum, na.rm=TRUE) ]

  bacvec <- bin_stats[,grepl('^Bac_',names(bin_stats)),with=F]
  arcvec <- bin_stats[,grepl('^Arc_',names(bin_stats)),with=F]

  if(nrow(bacvec)>0){
    uniqueBacSCGs <- sum(bacvec>0)
    multipleBacSCGs <- sum(bacvec>1)
    bacRatio <- uniqueBacSCGs / 51
    sumBacSCGs <- sum(bacvec)
    additionalBacSCGs <- sumBacSCGs - uniqueBacSCGs #- multipleBacSCGs
  }else{
    uniqueBacSCGs <- 0; multipleBacSCGs <- 0; bacRatio <- 0; sumBacSCGs <- 0; additionalBacSCGs <- 0
  }
    
  if(nrow(arcvec)>0){
    uniqueArcSCGs <- sum(arcvec>0)
    multipleArcSCGs <- sum(arcvec>1)
    arcRatio <- uniqueArcSCGs / 38
    sumArcSCGs <- sum(arcvec)
    additionalArcSCGs <- sumArcSCGs - uniqueArcSCGs #- multipleArcSCGs
  }else{
    uniqueArcSCGs <- 0; multipleArcSCGs <- 0; arcRatio <- 0; sumArcSCGs <- 0; additionalArcSCGs <- 0
  }

  # score <- max(a*bacRatio - b*(multipleBacSCGs / uniqueBacSCGs) - c*(additionalBacSCGs / (uniqueBacSCGs * 51)), (a*arcRatio - b*(multipleArcSCGs / uniqueArcSCGs) - c*(additionalArcSCGs / (uniqueArcSCGs * 38)) ),na.rm = T)
  score <- max(a*bacRatio - b*(multipleBacSCGs / uniqueBacSCGs) - c*(additionalBacSCGs /  51), (a*arcRatio - b*(multipleArcSCGs / uniqueArcSCGs) - c*(additionalArcSCGs /  38) ), na.rm = T)
  if(is.na(score)){
    return(0)
  }
  if(detailed_output){

    return(data.table(uniqueBacSCGs,multipleBacSCGs,additionalBacSCGs,sumBacSCGs,bacRatio,uniqueArcSCGs,multipleArcSCGs,additionalArcSCGs,sumArcSCGs,arcRatio,score))   #!
  }

  return(score)
}

#
# calculates N50 metric
calc.N50 <- function(seq_len,sort=T){
  if(sort){
    seq_len <- seq_len[order(seq_len,decreasing = T)]
  }
  N50 <- seq_len[cumsum(seq_len) > sum(seq_len)/2][1]

  return(N50)
}

#
# write log file and echo message
write.log <- function(message,append=T,filename,write_to_file=T,write_to_stdout=T){
  
  if( 'character' %in% class(message)){
    if(write_to_file){
      cat(message,'\n',file=filename,sep=' ',append = append)
    }
    if(write_to_stdout){
      cat(message,'\n')
    }
  }else if("data.frame" %in% class(message)){
    write.table(message,file=filename,sep='\t',col.names=F,row.names = F,quote=F,append = append)
    cat('\n',file=filename,sep=' ',append = append)
  }
}
