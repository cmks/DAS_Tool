#
# DAS Tool for genome-resolved metagenomics
# by Christian MK Sieber (csieber@lbl.gov)
#

DER_Plot <- function(result_list,filename){

  options(warn=-1)

  methods <- names(result_list)
  positions <- methods

  #stacked bar
  stats <- data.frame()
  for(i in 1:length(result_list)){
    evaluation <- result_list[[i]]
    evaluation$SCGRatio <- apply(data.frame( (evaluation$uniqueBacSCGs/51) , (evaluation$uniqueArcSCGs/38) ),1,max)*100
    evaluation$SCGDupeRatio <- apply(data.frame( (evaluation$multipleBacSCGs/51) , (evaluation$multipleArcSCGs/38) ),1,max)*100
    # > .9
    stats <- rbind(stats, data.frame(sample='High quality bins (< 5% contamination)',method=methods[i], completeness='>90%', bins=sum((evaluation$SCGRatio >= 90 & evaluation$SCGDupeRatio < 5 ) )))
    # .8 - .9
    stats <- rbind(stats, data.frame(sample='High quality bins (< 5% contamination)',method=methods[i], completeness='80-90%', bins=sum((evaluation$SCGRatio >= 80 & evaluation$SCGRatio < 90 & evaluation$SCGDupeRatio < 5 ) )))
    # .7 - .8
    stats <- rbind(stats, data.frame(sample='High quality bins (< 5% contamination)',method=methods[i], completeness='70-80%', bins=sum((evaluation$SCGRatio >= 70 & evaluation$SCGRatio < 80 & evaluation$SCGDupeRatio < 5 ) )))
    # .6 - .7
    stats <- rbind(stats, data.frame(sample='High quality bins (< 5% contamination)',method=methods[i], completeness='60-70%', bins=sum((evaluation$SCGRatio >= 60 & evaluation$SCGRatio < 70 & evaluation$SCGDupeRatio < 5 ) )))

  }

  #random changes in ggplot2 package...
  if(packageVersion("ggplot2")>=numeric_version("2.2.0")){
    stats$completeness <- factor(stats$completeness,levels = rev(c(">90%","80-90%","70-80%","60-70%")))
    colors <- rev(c("#08306B","#1664AB","#4A97C9","#93C4DE"))
  }else{
    stats$completeness <- factor(stats$completeness,levels = c(">90%","80-90%","70-80%","60-70%"))
    colors <- c("#08306B","#1664AB","#4A97C9","#93C4DE")
  }

  ggplot(stats, aes(method, bins, fill=completeness)) + geom_bar(stat="identity", position="stack")  +
    facet_grid( ~ sample)  + theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
    scale_fill_manual(values = colors) +  scale_x_discrete(limits = positions)
  ggsave(paste(filename,'_DASTool_hqBins.pdf',sep=''),width = 16,height=10)


  #violin+jitter
  stats2 <- data.frame()
  # my_colors <- c("#08306B","#084A92","#1664AB","#2E7EBB","#4A97C9","#6BAED6","#93C4DE","#B5D4E9","#CFE1F2","#E3EEF8")
  for(i in 1:length(result_list)){
    evaluation <- result_list[[i]]
    stats2 <- rbind(stats2, data.frame(sample='Score distribution of bins',method=methods[i], benchmark='score>=0.3', score=evaluation$score[ evaluation$score >=0.3 ]))
  }

  g<-ggplot(stats2, aes(x=method, y=score))
  g+geom_violin(alpha=0.5, color="gray")+geom_jitter(alpha=1.0, aes(color=method),position = position_jitter(width = 0.1)) + scale_x_discrete(limits = positions) + facet_grid( ~ sample) + theme(axis.text.x = element_text(angle = 90, hjust = 1))

  ggsave(paste(filename,'_DASTool_scores.pdf',sep=''),width = 16,height=10)
}

