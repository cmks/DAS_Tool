#
# DAS Tool for genome-resolved metagenomics
# by Christian MK Sieber (csieber@lbl.gov)
#

#' DAS Tool
#'
#' This is the main function of DAS Tool.
#' Please use DAS_Tool.sh in your installation folder to run DAS Tool.
#' DAS Tool is available at https://github.com/cmks/DAS_Tool
#' Please cite https://doi.org/10.1101/107789
#'
#' @param scaffolds_to_bins Comma separated string of tab separated scaffolds to bin files.
#' @param bin_set_labels Comma separated string of binning prediction names.
#' @param length_table Tab separated file of scaffold names and scaffold lengths.
#' @param bac_scg_matrix Tab separated file of scaffold names and predicted bacterial single copy genes.
#' @param arc_scg_matrix Tab separated file of scaffold names and predicted archaeal single copy genes.
#' @param score_threshold Score threshold until selection algorithm will keep selecting bins [0..1].
#' @param output_basename Basename of output files.
#' @param trim_headers Logical value indicating whether scaffold headers should be trimmed after the first whitespace.
#' @param write_bin_evals  Logical value indicating whether evaluations for each input bin set should be written.
#' @return List of binning evaluations.
cherry_pick <- function(scaffolds_to_bins,bin_set_labels,length_table,bac_scg_matrix,arc_scg_matrix,score_threshold=0.1,a=1,b=1.5,c=1,output_basename='DASTool',trim_headers=T,use_N50=T,write_bin_evals=T,debug=F){

  if(debug){
    cat('1. scaffolds_to_bins ',scaffolds_to_bins,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = F)
    # 2.labels $binlabels
    cat('2. bin_set_labels ',bin_set_labels,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 3.contigs $contigs
    cat('3. assembly ',assembly,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 4.bac_scg $bscg
    cat('4. bac_scg_matrix ',bac_scg_matrix,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 5.arc_scg $ascg
    cat('5. arc_scg_matrix ',arc_scg_matrix,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 6.out $outputbasename
    cat('6. output_basename ',output_basename,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 7.score_threshold $score_threshold
    cat('7. score_threshold ',score_threshold,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 8.threads $threads
    cat('8. threads ',threads,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 9.workingdir $thisdir
    cat('9. workingdir ',workingdir,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 10.length_table $length_table
    cat('10. length_table ',length_table,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 11.write_bin_evals $write_bin_evals
    cat('11. write_bin_evals ',write_bin_evals,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 12.create_plots $create_plots
    cat('12. create_plots ',create_plots,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
    # 13.debug $debug
    cat('13. debug ',debug,'\n',file=paste0(output_basename,'_DASTool.log'),sep='',append = T)
  }

  rank_bins=F

  internal_ratio_threshold <- 0.0
  score_threshold <- max(score_threshold,-41)

  if(bin_set_labels=="NULL"){
    bin_set_labels <- NULL
  }

  #
  # get assembly information
  # assembly_info <- data.table(scaffold_name=names(scaffolds),length=width(scaffolds))
  assembly_info <- fread(length_table,sep='\t',header=F,col.names=c('scaffold_name','length'))


  if(trim_headers){
    assembly_info$scaffold_name <- gsub(' .*','',assembly_info$scaffold_name)
  }


  setkey(assembly_info,scaffold_name)


  #Read bin-set bin2scaffold-files:
  bin_sets <- unlist(strsplit(scaffolds_to_bins,','))
  bin_set_list <- list()
  uqbins <- data.frame()
  for(i in 1:length(bin_sets)){

    result = tryCatch({
      bin_set_list[[i]] <- read.table(bin_sets[i],header = F,sep = '\t',stringsAsFactors = F)
      colnames(bin_set_list[[i]]) <- c('scaffold_name','bin')

      if(max(table(bin_set_list[[i]]$scaffold_name)) > 1){
        cat('WARNING: Duplicated scaffolds in: ', bin_sets[i],'\n',sep='')
        if(length(unique(bin_set_list[[i]]$scaffold_name)) < length(unique(bin_set_list[[i]]$bin))){
          cat('\tscaffold_name and bin_id columns flipped? Should be: scaffold_name \\t bin_id\n')
        }
      }
    }, error = function(e) {
      cat('ERROR: Cannot read scaffold2bin file: ',bin_sets[i],'.\n\tPlease check file/format. Should be: scaffold_name \\t bin_id\n',sep='')
    })

    uqbins <- rbind(uqbins,data.frame(bin=unique(bin_set_list[[i]]$bin),binset=basename(bin_sets[i])))

    if(trim_headers){
      bin_set_list[[i]]$scaffold_name <- gsub(' .*','',bin_set_list[[i]]$scaffold_name)
    }

    #check if scaffolds of scaffolds2bin match names in assembly_info:
    if(!any( bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name )){
      cat('ERROR: Scaffold names of',bin_sets[i],'do not match assembly headers\n')
      cat('\tFormat of ',basename(assembly),': ', paste(head(assembly_info$scaffold_name),collapse=' '),sep='','\n')
      cat('\tFormat of ',basename(bin_sets[i]),': ', paste(head(bin_set_list[[i]]$scaffold_name),collapse=' '),sep='','\n')
      # cat('   NOT FOUND from',basename(bin_sets[i]),': ', paste(head(bin_set_list[[i]]$scaffold_name[ ! bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name]),collapse=' ',sep=''),'\n')
      return(F) #Exit here
    }else if(!all( bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name )){
      cat('WARNING: Some scaffold names of',bin_sets[i],'do not match assembly headers:\n')
      cat('\t', paste(head(bin_set_list[[i]]$scaffold_name[ ! bin_set_list[[i]]$scaffold_name %in% assembly_info$scaffold_name]),collapse=' '),sep='','\n')
      # cat('   ',basename(assembly),': ', paste(head(assembly_info$scaffold_name),collapse=' '),sep='','\n')
      #return(F) #Exit here
    }

  }

  #Rename bin-IDs if not unique:
  uqtest <- table(uqbins$bin)
  if(max(uqtest) > 1){
    cat('WARNING: non-unique bin-IDs found\n\tcreating unique bin-IDs\n')
    for(i in 1:length(bin_sets)){
      bins_uq <- unique(bin_set_list[[i]]$bin)
      map <- data.frame(new=gsub('_scaffolds2bin','',paste(strsplit(basename(bin_sets[i]),'.',fixed=T)[[1]][1],'.',sprintf('%03d',c(1:length(bins_uq))),sep='')),old=bins_uq)
      bin_set_list[[i]]$bin <- map$new[ match(bin_set_list[[i]]$bin,map$old) ]
    }
  }

  #Check if same amount of bin-sets and labels are given:
  if(!is.null(bin_set_labels)){
    if(length(unlist(strsplit(bin_set_labels,','))) != length(unlist(strsplit(scaffolds_to_bins,',')))){
      cat('WARNING: number of bin-sets does not match number of labels\n\tcreating labels from file names\n')
      bin_set_labels <- NULL
    }
  }

  #Create bin-set labels if no labels are given:
  if(!is.null(bin_set_labels)){
    names(bin_set_list) <- unlist(strsplit(bin_set_labels,','))
  }else{
    # bin_set_labels <- unlist(lapply(bin_sets,function(x){strsplit(basename(x),'.',fixed=T)[[1]][1]}))
    bin_set_labels <- unlist(lapply(bin_sets,function(x){gsub('\\.[a-z]{3}$','',basename(x))}))
    names(bin_set_list) <- unlist(strsplit(bin_set_labels,','))
  }

  #Rename bin-set labels if not unique:
  uqtest2 <- table(bin_set_labels)
  if(max(uqtest2) > 1){
    bin_set_labels <- paste(bin_set_labels,c(1:length(bin_set_labels)),sep='.')
    names(bin_set_list) <- unlist(strsplit(bin_set_labels,','))
  }

  #
  # Build scg_matrix
  # cat('assembling SCG matrix\n')
  if(class(bac_scg_matrix)=='character'){
    bac_scg <- read.table(bac_scg_matrix, header = F,sep = '\t',stringsAsFactors = F,quote = '',col.names=c('contig','Bacterial.SCG'))
    bac_scg$contig <- gsub('\\_[0-9]+$','',bac_scg$contig)
  }else{
    bac_scg <- bac_scg_matrix
  }
  bac_scg$tmp  <- paste(bac_scg$contig,bac_scg$Bacterial.SCG,sep = '_')
  bac_scg <- bac_scg[!duplicated(bac_scg$tmp),]
  tmp  <- table(bac_scg$tmp)
  bac_scg$count <- tmp[bac_scg$tmp]
  tmp2 <- aggregate(bac_scg["count"], by=bac_scg[c("Bacterial.SCG","contig")], FUN=sum)
  bacSCGMat <- reshape(tmp2,timevar = 'Bacterial.SCG',idvar = 'contig',direction = "wide")
  colnames(bacSCGMat) <- gsub('^count\\.','Bac_',colnames(bacSCGMat))


  if(class(arc_scg_matrix)=='character'){
    arc_scg <- read.table(arc_scg_matrix, header = F,sep = '\t',stringsAsFactors = F,quote = '',col.names=c('contig','Archaeal.SCG'))
    arc_scg$contig <- gsub('\\_[0-9]+$','',arc_scg$contig)
  }else{
    arc_scg <- arc_scg_matrix
  }
  arc_scg$tmp  <- paste(arc_scg$contig,arc_scg$Archaeal.SCG,sep = '_')
  arc_scg <- arc_scg[!duplicated(arc_scg$tmp),]
  tmp  <- table(arc_scg$tmp)
  arc_scg$count <- tmp[arc_scg$tmp]
  tmp2 <- aggregate(arc_scg["count"], by=arc_scg[c("Archaeal.SCG","contig")], FUN=sum)
  arcSCGMat <- reshape(tmp2,timevar = 'Archaeal.SCG',idvar = 'contig',direction = "wide")
  colnames(arcSCGMat) <- gsub('^count\\.','Arc_',colnames(arcSCGMat))

  SCGMat <- merge(x = bacSCGMat, y = arcSCGMat, by = "contig", all = TRUE)
  SCGMat[is.na(SCGMat)] <- 0
  rownames(SCGMat) <- SCGMat$contig

  if(trim_headers){
    SCGMat$contig <- gsub(' .*','',SCGMat$contig)
  }
  SCGMat <- as.data.table(SCGMat)
  setkey(SCGMat,contig)


  #
  # evaluate bin-sets
  cat('evaluating bin-sets\n')
  eval_bin_set_list <- list()
  eval_bin_set_list[names(bin_set_list)] <- list(NULL)
  for(i in 1:length(bin_set_list)){

    eval_bin_set_list[[i]] <- evaluateBinsDTParallel_2(bin_table = bin_set_list[[i]],SCGMat,assembly_info,a=a,b=b,c=c,method=rank_bins)

    # evaluation <- eval_bin_set_list[[i]]
    # evaluation$SCGRatio <- apply(data.frame( (evaluation$uniqueBacSCGs/51) , (evaluation$uniqueArcSCGs/38) ),1,max)*100
    # evaluation$SCGDupeRatio <- apply(data.frame( (evaluation$multipleBacSCGs/51) , (evaluation$multipleArcSCGs/38) ),1,max)*100

    if(write_bin_evals){
      write.table(eval_bin_set_list[[i]][,c('bin', 'uniqueBacSCGs', 'multipleBacSCGs', 'bacRatio', 'uniqueArcSCGs', 'multipleArcSCGs',  'arcRatio', 'size', 'nContigs', 'N50', 'score'),with=F],paste(output_basename,'_',names(bin_set_list)[i],'.eval',sep=''),sep='\t',col.names=T,row.names=F,quote=F)
    }
    eval_bin_set_list[[i]] <- eval_bin_set_list[[i]][eval_bin_set_list[[i]]$score> score_threshold,]
    bin_set_list[[i]] <- as.data.table(bin_set_list[[i]])
    setkey(bin_set_list[[i]],bin)
    bin_set_list[[i]] <- bin_set_list[[i]][.(eval_bin_set_list[[i]]$bin)]
  }


  bin_list <- list()
  for(i in 1:length(bin_set_list)){
    binS1 <- bin_set_list[[i]]
    if(debug){
      cat('binS1 #',i,' dimensions: ',dim(binS1)[1],' x ',dim(binS1)[2],'\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
      write.table(head(binS1),file=paste(output_basename,'_DASTool.log',sep=''),sep='\t',col.names=F,row.names = F,quote=F,append = T)
      cat('\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
    }
    bin_list[[(length(bin_list)+1)]] <- data.table(bin=binS1$bin,scaffold_name=binS1$scaffold_name)
  }

  bin_table <- rbindlist(bin_list,fill = T)
  if(debug){
    cat('bin_table dimensions: ',dim(bin_table)[1],' x ',dim(bin_table)[2],'\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
    write.table(head(bin_table),file=paste(output_basename,'_DASTool.log',sep=''),sep='\t',col.names=F,row.names = F,quote=F,append = T)
    cat('\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
  }
  bin_summary <- evaluateBinsDTParallel_2(bin_table,SCGMat,assembly_info = assembly_info,a=a,b=b,c=c,method=rank_bins)
  bin_summary$maxRatio  <- apply(data.frame(bin_summary$bacRatio, bin_summary$arcRatio),1,max)

  optibin_table <- list()
  optibin_summary <- list()
  optimization_trace <- list()

  bin_table  <- bin_table[ bin_table$bin %in% bin_summary$bin[ bin_summary$maxRatio > internal_ratio_threshold ],]
  bin_table <- bin_table[,.(scaffold_name,bin)]
  setkey(bin_table,bin)
  bin_summary <- bin_summary[ bin_summary$maxRatio > internal_ratio_threshold, ]

  if(use_N50){
    bin_summary <- bin_summary[order(bin_summary$score,bin_summary$N50,bin_summary$size,decreasing = T),]
    bin_summary <- bin_summary[,maxRatio:=NULL]
  }else{
    bin_summary <- bin_summary[order(bin_summary$score,bin_summary$size,decreasing = T),]
    bin_summary <- bin_summary[,maxRatio:=NULL]
  }

  # Compute Score-Matrix and Rank-Scores
  max_score <- max(bin_summary$score)


  first=T
  cat('starting bin selection from ', dim(bin_summary)[1],' bins\n')
  step <- 1
  while(max_score >= score_threshold){

    cat('|')

    if(!is.null(output_basename)){
      write.table(bin_table[ .(bin_summary$bin[1]) ],file=paste(output_basename,'_DASTool_scaffolds2bin.txt',sep=''),append = !first,quote=F,row.names = F,col.names=F,sep='\t')
      write.table(bin_summary[ bin_summary$bin ==  bin_summary$bin[1], c('bin', 'uniqueBacSCGs', 'multipleBacSCGs', 'bacRatio', 'uniqueArcSCGs', 'multipleArcSCGs',  'arcRatio', 'size', 'nContigs', 'N50', 'score'),with=F],file=paste(output_basename,'_DASTool_summary.txt',sep=''),append = !first,quote=F,row.names = F,col.names=first,sep='\t')
      # write.table(data.table(bin=bin_summary$bin[1],score=bin_summary$score[1]),file=paste(output_basename,'_DASTool_trace.txt',sep=''),append = !first,quote=F,row.names = F,col.names=first,sep='\t')
      first=F
    }else{
      optibin_table[[(length(optibin_table)+1)]] <- bin_table[ .(bin_summary$bin[1]) ] #first line of bin_summary has highest score!
      optibin_summary[[(length(optibin_summary)+1)]] <- bin_summary[ bin_summary$bin ==  bin_summary$bin[1], ]
      optimization_trace[[(length(optimization_trace)+1)]] <- data.table(bin=bin_summary$bin[1],bin_summary$score[1])  #!
    }

    affected_scaffolds <- bin_table[ .(bin_summary$bin[1]), scaffold_name ]
    affected_bins <- unique(bin_table[ bin_table$scaffold_name %in% affected_scaffolds , bin])

    if(debug){
      cat('================== Iteration No ',step,': ==================\n',file=paste(output_basename,'_DASTool.log',sep=''),sep='',append = T)
      cat('Selected bin:\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
      write.table(bin_summary[ bin_summary$bin ==  bin_summary$bin[1], ],file=paste(output_basename,'_DASTool.log',sep=''),sep='\t',col.names=F,row.names = F,quote=F,append = T)
      cat('-------------------','\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
      cat('Affected bins:','\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
      write.table(bin_summary[ bin_summary$bin %in% affected_bins, ],file=paste(output_basename,'_DASTool.log',sep=''),sep='\t',col.names=F,row.names = F,quote=F,append = T)
      # cat(paste(affected_bins,collapse = ', '),'\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
    }

    bin_table <- bin_table[ !bin_table$scaffold_name %in% affected_scaffolds ,]
    bin_summary <- bin_summary[ !bin_summary$bin %in% affected_bins, ]

    affected_bin_table <- bin_table[ .(affected_bins), ]
    affected_bin_table <- affected_bin_table[!is.na(affected_bin_table$scaffold_name),]

    if(dim(affected_bin_table)[1] > 0){
      new_bin_summary <- evaluateBinsDTParallel_2(bin_table = affected_bin_table, SCGMat,assembly_info = assembly_info,a=a,b=b,c=c,method=rank_bins)
      if(rank_bins){
        new_bin_summary$r <- bin_rank$rank[match(new_bin_summary$method,bin_rank$method)]
      }
      bin_summary <- rbind(bin_summary,new_bin_summary)

      if(debug){
        cat('-------------------','\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
        cat('Updated bins:\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
        write.table(new_bin_summary,file=paste(output_basename,'_DASTool.log',sep=''),sep='\t',col.names=F,row.names = F,quote=F,append = T)
        cat('\n',file=paste(output_basename,'_DASTool.log',sep=''),sep=' ',append = T)
      }
    }

    if(dim(bin_summary)[1] != 0){
      if(use_N50){
        bin_summary <- bin_summary[order(bin_summary$score,bin_summary$N50,bin_summary$size,decreasing = T),]
        max_score <- max(bin_summary$score)
      }else{
        bin_summary <- bin_summary[order(bin_summary$score,bin_summary$size,decreasing = T),]
        max_score <- max(bin_summary$score)
      }

    }else{
      max_score <- -42
    }
    step <- step + 1
  }
  cat('\n')

  dastool_bineval <- read.table(paste(output_basename,'_DASTool_summary.txt',sep=''),sep='\t',header=T)
  eval_bin_set_list <- c(eval_bin_set_list,list(DAS_Tool=dastool_bineval))

  return(eval_bin_set_list)
}


#
# scores a scaffold2bins table using a single copy gene matrix
evaluateBinsDTParallel_2 <- function(bin_table, SCGMat, assembly_info=NULL, a=1, b=1.5, c=1,hmm=F,method=F){

  bin_table <- as.data.table(bin_table)
  setkey(bin_table,bin)
  # if(!is.null(assembly_info)){
  #   scaffold_table <- data.table(scaffold_names=names(assembly_info),length=assembly_info)
  #   setkey(scaffold_table,scaffold_names)
  # }
  bins_uq <- unique(bin_table$bin)

  bin_stats_list <- foreach(i=1:length(bins_uq)) %dopar% {
    scaffold_ids <- unique(bin_table[.(bins_uq[i]), scaffold_name])
    if(!hmm){
      # cat(bins_uq[i],scaffold_ids[1],a,b,c)
      data.table(bin=bins_uq[i],scoreBinDT(scaffold_ids, SCG_mat=SCGMat, a=a, b=b, c=c, detailed_output=T))
    }else{
      data.table(bin=bins_uq[i],scoreBinDT_HMM(scaffold_ids, SCG_mat=SCGMat, a=a, b=b, c=c, detailed_output=T))
    }
  }
  bin_stats <- rbindlist(bin_stats_list,fill = T)

  # cat('assembly info:', is.null(assembly_info))
  if(!is.null(assembly_info)){
    bin_stats$size <- 0
    bin_stats$nContigs <- 0
    bin_stats$N50 <- 0
    for(i in 1:length(bin_stats$bin)){
      dt1 <- bin_table[.(bin_stats$bin[i]),  ]
      setkey(dt1,scaffold_name)
      bin_stats$size[i] <- assembly_info[ .(dt1[,scaffold_name]), sum(length,na.rm = T)]
      bin_stats$nContigs[i] <- dim(dt1)[1]
      bin_stats$N50[i] <- calc.N50(assembly_info[ .(dt1[,scaffold_name]), length])
    }
  }
  if(method){
    bin_stats$method <- unlist(lapply(bin_stats$bin,function(x){strsplit(x,'\\.')[[1]][1]}))
  }

  return(bin_stats)
}


#
# scores a single bin using a single copy gene matrix
scoreBinDT <- function(scaffold_ids, SCG_mat, a=1, b=1.5, c=1, detailed_output=F){

  if(! any(SCG_mat$contig %in% scaffold_ids)){

    return(data.frame(uniqueBacSCGs=0,multipleBacSCGs=0,additionalBacSCGs=0,sumBacSCGs=0,bacRatio=0,uniqueArcSCGs=0,multipleArcSCGs=0,additionalArcSCGs=0,sumArcSCGs=0,arcRatio=0,score=0))
  }

  tmp <- SCG_mat[ .(scaffold_ids) , ]
  tmp <- tmp[,contig :=NULL ]
  bin_stats <- tmp[, lapply(.SD, sum, na.rm=TRUE) ]

  bacvec <- bin_stats[,grepl('^Bac_',names(bin_stats)),with=F]
  arcvec <- bin_stats[,grepl('^Arc_',names(bin_stats)),with=F]

  uniqueBacSCGs <- sum(bacvec>0)
  multipleBacSCGs <- sum(bacvec>1)
  bacRatio <- uniqueBacSCGs / 51
  sumBacSCGs <- sum(bacvec)
  additionalBacSCGs <- sumBacSCGs - uniqueBacSCGs #- multipleBacSCGs

  uniqueArcSCGs <- sum(arcvec>0)
  multipleArcSCGs <- sum(arcvec>1)
  arcRatio <- uniqueArcSCGs / 38
  sumArcSCGs <- sum(arcvec)
  additionalArcSCGs <- sumArcSCGs - uniqueArcSCGs #- multipleArcSCGs

  # score <- max(a*bacRatio - b*(multipleBacSCGs / uniqueBacSCGs) - c*(additionalBacSCGs / (uniqueBacSCGs * 51)), (a*arcRatio - b*(multipleArcSCGs / uniqueArcSCGs) - c*(additionalArcSCGs / (uniqueArcSCGs * 38)) ),na.rm = T)
  score <- max(a*bacRatio - b*(multipleBacSCGs / uniqueBacSCGs) - c*(additionalBacSCGs /  51), (a*arcRatio - b*(multipleArcSCGs / uniqueArcSCGs) - c*(additionalArcSCGs /  38) ), na.rm = T)
  if(is.na(score)){
    return(0)
  }
  if(detailed_output){

    return(data.table(uniqueBacSCGs,multipleBacSCGs,additionalBacSCGs,sumBacSCGs,bacRatio,uniqueArcSCGs,multipleArcSCGs,additionalArcSCGs,sumArcSCGs,arcRatio,score))   #!
  }

  return(score)
}

#
# calculates N50 metric
calc.N50 <- function(seq_len,sort=T){
  if(sort){
    seq_len <- seq_len[order(seq_len,decreasing = T)]
  }
  N50 <- seq_len[cumsum(seq_len) > sum(seq_len)/2][1]

  return(N50)
}
